<!--html5 doctype -->
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="apple-touch-icon" sizes="180x180" href="../apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../favicon-16x16.png">
        <link rel="manifest" href="../site.webmanifest">
        <title>livefreely</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" type="text/css" href="/css/navBar.css">
        <link rel="stylesheet" type="text/css" href="/css/dbImages.css">
    </head>
    <body>
        <div class="topnav">
            <a href="home.php"><img id="logo" src="../images/LFLogoTransparent.png" alt="livefreely"></a>
            <input type="text" id="search" placeholder="Search...">
            <a href="../logout.php" id="logout">Sign Out</a>

            <div class="navlinks" id="myTopnav">
                <a href="tech.php" class="linkstext">Tech</a>
                <a href="yourHome.php" class="linkstext">Your Home</a>
                <a href="customCreations.php" class="linkstext">Custom Creations</a>
                <a href="marketing.php" class="linkstext" >Marketing</a>
                <a href="music.php" class="linkstext">Music</a>
            </div>
        </div>
        <div class="gridContainer">
            <div class="gridContainer">
            <h1>Upload something<a href="form.php" here!/a><b><i> here!</i></b></a></h1>
            <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "LIVEFREELY";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                $sql = "SELECT id, image, image_text FROM images";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        if($row['image_text'] == "tech"){
            ?>
                            <a href="tech.php">
                            <?php
                                echo "<div class='img_div'>";
                                    echo "<img src='../images/".$row['image']."'>";
                                echo "</div>";
                            ?>
                            </a>
                        <?php
                        }
                    } 
                }else{
                    echo "0 results";
                }
                $conn->close();
                ?>
            </div>
        </div>
    </body>
</html>