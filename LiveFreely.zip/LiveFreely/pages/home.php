<!--html5 doctype -->
<!DOCTYPE html>
<?php
// Created by Professor Wergeles for CS2830 at the University of Missouri
    
	// Every time we want to access $_SESSION, we have to call session_start()
	if(!session_start()) {
		header("Location: error.php");
		exit;
	}
	
	$loggedIn = empty($_SESSION['loggedin']) ? false : $_SESSION['loggedin'];
	if (!$loggedIn) {
		header("Location: home.php");
		exit;
	}
?>
<html lang="en">
    <head>
               <link rel="apple-touch-icon" sizes="180x180" href="../apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../favicon-16x16.png">
<link rel="manifest" href="../site.webmanifest">
        <title>livefreely</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" type="text/css" href="/css/index.css">
        <link rel="stylesheet" type="text/css" href="/css/dbImages.css">
        <link rel="stylesheet" type="text/css" href="/css/navBar.css">
    </head>
    <body>
        <div class="topnav">
            <a href="home.php"><img id="logo" src="/images/LFLogoTransparent.png" alt="livefreely"></a>
            <input type="text" id="search" placeholder="Search...">
            <a id="signout" href="../logout.php">Sign Out</a>
            
        <div class="navlinks" id="myTopnav">
            <a href="tech.php" class="linkstext">Tech</a>
            <a href="yourHome.php" class="linkstext">Your Home</a>
            <a href="customCreations.php" class="linkstext">Custom Creations</a>
            <a href="marketing.php" class="linkstext">Marketing</a>
            <a href="music.php" class="linkstext" id="custom">Music</a>
        </div>
        </div>
        <div class="slideshow">
            <div class="mySlides fade">
                <img src="/images/slideshow1.png" class="slideshowimg" alt="one">
            </div>
            <div class="mySlides fade">
                <img src="/images/slideshow2.png" class="slideshowimg" alt="two">
            </div>
            <div class="mySlides fade">
                <img src="/images/slideshow3.png" class="slideshowimg" alt="three">
            </div>
            <div class="mySlides fade">
                <img src="/images/slideshow4.png" class="slideshowimg" alt="four">
            </div>
            
            <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="next" onclick="plusSlides(1)">&#10095;</a>

            <div style="text-align:center">
                <span class="dot" onclick="currentSlide(1)"></span>
                <span class="dot" onclick="currentSlide(2)"></span>
                <span class="dot" onclick="currentSlide(3)"></span>
                <span class="dot" onclick="currentSlide(4)"></span>
            </div>
        </div>
        <script src="../js/index.js"></script>
        <div class="columnContainer">
            <div class="column"id="column1">
                <h1>Working Smarter</h1>
                <hr>
                <p>By connecting your social media, livefreely provides safe, secure, and efficient way to showcase your unique creations.</p>
            </div>
            <div class="column"id="column1">
                <h1>Be Your Own Boss</h1>
                <hr>
                <p>Livefreely works to empower our users by giving them the tools and independence to thrive on their own time. </p>
            </div>
            <div class="column"id="column1">
                <h1>One-Of-A-Kind</h1>
                <hr>
                <p>Everything created here is one of a kind, you can't go anywhere else for it!</p>
            </div>
        </div>
        <div class="gridContainer">
            <h1>Need Something? Click what you like and see more!</h1>
            <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "LIVEFREELY";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "SELECT id, image, image_text FROM images";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        if($row['image_text'] == "clothes" || $row['image_text'] == "food" || $row['image_text'] == "beauty" || $row['image_text'] == " "){
            ?>
                            <a href="customCreations.php">
                            <?php
                                echo "<div class='img_div'>";
                                    echo "<img src='/images/".$row['image']."'>";
                                echo "</div>";
                            ?>
                            </a>
                        <?php
                        }if($row['image_text'] == "art" || $row['image_text'] == "build"){
            ?>
                            <a href="yourHome.php">
                            <?php
                                echo "<div class='img_div'>";
                                    echo "<img src='/images/".$row['image']."'>";
                                echo "</div>";
                            ?>
                            </a>
                        <?php
                        }if($row['image_text'] == "marketing" || $row['image_text'] == "event"){
            ?>
                            <a href="marketing.php">
                            <?php
                                echo "<div class='img_div'>";
                                    echo "<img src='/images/".$row['image']."'>";
                                echo "</div>";
                            ?>
                            </a>
                        <?php
                        }if($row['image_text'] == "tech"){
            ?>
                            <a href="tech.php">
                            <?php
                                echo "<div class='img_div'>";
                                    echo "<img src='/images/".$row['image']."'>";
                                echo "</div>";
                            ?>
                            </a>
                        <?php
                        }
                    } 
                }else{
                    echo "0 results";
                }
                $conn->close();
                ?>
            </div>
        <div class="clearfix"></div>
    </body>
</html>