<?php
  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "LIVEFREELY");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$image = $_FILES['image']['name'];
  	// Get text
  	$image_text = mysqli_real_escape_string($db, $_POST['image_text']);

  	// image file directory
  	$target = "images/".basename($image);

  	$sql = "INSERT INTO images (image, image_text) VALUES ('$image', '$image_text')";
  	// execute query
  	mysqli_query($db, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  $result = mysqli_query($db, "SELECT * FROM images");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Image Upload</title>
    <link rel="apple-touch-icon" sizes="180x180" href="../apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../favicon-16x16.png">
    <link rel="manifest" href="../site.webmanifest">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <link rel="stylesheet" type="text/css" href="/css/form.css">
    <script>
        $(function() {
            $(".content").draggable();
          } );
    </script>
</head>
<body>
    <div class="topnav">
        <link rel="stylesheet" type="text/css" href="/css/navBar.css">
            <a href="home.php"><img id="logo" src="/images/LFLogoTransparent.png" alt="livefreely"></a>
            <input type="text" id="search" placeholder="Search...">
            <a id="signout" href="../logout.php">Sign Out</a>
            
        <div class="navlinks" id="myTopnav">
            <a href="tech.php" class="linkstext">Tech</a>
            <a href="yourHome.php" class="linkstext">Your Home</a>
            <a href="customCreations.php" class="linkstext">Custom Creations</a>
            <a href="marketing.php" class="linkstext">Marketing</a>
            <a href="music.php" class="linkstext" id="custom">Music</a>
        </div>
        </div>
    <div class="content">
        <div id="title">
            <h1>Post something! (you can drag the box too!)</h1>
            <p>ONLY "iframe" embedded links.</p>
        </div>
    <div class="form">
      <form method="POST" action="form.php" enctype="multipart/form-data">
          <input type="hidden" name="size" value="1000000" required>
          <input type="file" name="image">
          <input type="text" id="text" cols="40" rows="4" name="image_text" placeholder="What is your craft?...">
          <button type="submit" name="upload">Upload</button>
      </form>
    </div>
    </div>
</body>
</html>