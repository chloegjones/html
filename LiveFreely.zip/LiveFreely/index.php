<!--html5 doctype -->
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="manifest" href="/site.webmanifest">
        <title>Login Page</title>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="/css/login.css">
            <script src="../jquery-ui-1.11.4.custom/external/jquery/jquery.js"></script>
    <script src="../jquery-ui-1.11.4.custom/jquery-ui.min.js"></script>
    <script>
        $(function(){
            $("input[type=submit]").button();
        });
    </script>
    </head>
    <body>
        <div class="login">
			<h1>Login</h1>
            <?php
            if ($error) {
                print "<div class=\"ui-state-error\">$error</div>\n";
            }
        ?>
			<form action="login.php" method="POST">
                <input type="hidden" name="action" value="do_login">
				<input type="text" name="username" placeholder="Username" id="username" value="<?php print $username; ?>"required>
				<input type="password" name="password" placeholder="Password" id="password" required>
				<input type="submit" value="Submit">
			</form>
		</div>
    </body>
</html>