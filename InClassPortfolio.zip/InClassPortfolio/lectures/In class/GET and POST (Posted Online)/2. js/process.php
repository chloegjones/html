<?php
// Created by Professor Wergeles for CS2830 at the University of Missouri 

    $schoolId = $_GET['sid'];

    $text = $_POST['myText'];

    print "The school id is set to $schoolId and the text submitted is $text";

?>