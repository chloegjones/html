<?php
// Created by Professor Wergeles for CS2830 at the University of Missouri 

	$user = $_POST['user']; 
	
	//print "Thank you for logging in, $user!";
	print "Thank you for logging in, ".$user."!"; 
?>