<!DOCTYPE html>
<!-- Created by Professor Wergeles for CS2830 at the University of Missouri -->
<html>
<head>
	<title>Case Sensitivity</title>
</head>
<body>

	<?php

		ECHO "Hello World!<br>";
		echo "Hello World!<br>";
		EcHo "Hello World!<br>";


		$color = "red";
		echo "My car is " . $color . "<br>";
		echo "My house is " . $COLOR . "<br>";
		echo "My boat is " . $coLOR . "<br>";
	?>

</body>
</html>
