<!DOCTYPE html>
<!-- Created by Professor Wergeles for CS2830 at the University of Missouri -->
<html>
<head>
	<title>First PHP</title>
</head>
	<body>

	<h1>My first PHP page</h1>

	<?php
		echo "<h1>hello world</h1>";
	?>

	</body>
</html>