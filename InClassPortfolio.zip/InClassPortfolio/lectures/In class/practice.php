<!--html5 doctype -->
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>My First Page</title>
        <meta charset="utf-8">
    </head>
    <body>
        <div id="phpDiv">
            <p id="title">Result</p>
        <?php
            $count = 0;
            echo $count;
            $count = 1;
            echo $count;
        ?>
    </div>
    </body>
</html>
