<?php
// Created by Professor Wergeles for CS2830 at the University of Missouri
    sleep(1);

    $me = array("name" => "Professor Wergeles", "pet" => "Tiger");
    
//("name": Professor Wergeles, pet, tiger

//print '{"name": "' . $me['name'] . '", "pet": "' . $me['pet'] . '"}';

//json_encode funct

print json_encode($me);

?>
