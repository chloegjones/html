<!--html5 doctype -->
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>My First Page</title>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="PHP.css">
        <style>
            
        </style>
    </head>
    <body>
        <div id="phpDiv">
            <p id="title">Result</p>
        <?php
            $number = $_GET['number'];
            $string = $_GET['string'];
            $n1 = $_GET['n1'];
            $n2 = $_GET['n2'];
            $function = $_GET['mainDropDown'];

            function greeting($firstName, $lastName){
                echo "Hello $firstName $lastName\n<br>";
            }
            //https://www.geeksforgeeks.org/php-factorial-number/    
            function factorial($n){
                $factorial = 1;
                for($i = 1; $i <= $n; $i++){
                    $factorial = $factorial * $i;
                }
                echo "The factorial of $n is $factorial<br>";
            }
            //https://www.php.net/manual/en/function.strrev.php
            function stringReverse($string){
                $reversed = strrev($string);
                echo "The reverse of $string is $reversed<br>";
            }
            function squares($integer1, $integer2){
                if($integer1 > $integer2 or $integer1 < 1 or $integer2 < 1){
                    echo "Error, n1 > n2. n1 must be less than n2 and they must be greater than or = to 1<br>";
                    return 0;
                }else{
                    $sum1 = 0;
                    for($i = $integer1; $i <= $integer2; $i++){
                        $sum += $i * $i;
                    }
                    echo "The sum of squares between $integer1 and $integer2 is $sum<br>";
                }
            }
            if($_SERVER['REQUEST_METHOD'] === 'POST') { 
                $firstName = $_POST['firstName'];
                $lastName = $_POST['lastName'];

                greeting($firstName, $lastName);

                foreach ($_POST as $key => $value) {
                    if($key == 'mainDropDown'){
                        print "Function ran: $value\n<br>";
                    }
                    if($key == 'firstName'){
                        print "Input Parameters: $key = $value\n<br>";
                    }
                    if($key == 'lastName'){
                        print "Input Parameters: $key = $value\n<br>";
                    }
                }
            }
            if($_SERVER['REQUEST_METHOD'] === 'GET') {


                if($number != ""){
                    factorial($number);
                    foreach ($_GET as $key => $value) {
                    if($key == 'mainDropDown'){
                        print "\nFunction ran: $value\n<br>";
                    }
                    if($key == 'number'){
                        print "Input Parameters: $key = $value\n<br>";
                    }
                }
                }

                if($string != ""){
                    stringReverse($string);
                    foreach ($_GET as $key => $value) {
                    if($key == 'mainDropDown'){
                        print "\nFunction ran: $value\n<br>";
                    }
                    if($key == 'string'){
                        print "Input Parameters: $key = $value\n<br>";
                    }
                }
                }

                if($n1 != ""){
                    squares($n1, $n2);
                    foreach ($_GET as $key => $value) {
                    if($key == 'mainDropDown'){
                        print "\nFunction ran: $value\n<br>";
                    }
                    if($key == 'n1'){
                        print "Input Parameters: $key = $value\n<br>";
                    }
                        if($key == 'n2'){
                        print "Input Parameters: $key = $value\n<br>";
                    }
                }
                }
                
                
            }
        ?>
    </div>
    </body>
</html>
