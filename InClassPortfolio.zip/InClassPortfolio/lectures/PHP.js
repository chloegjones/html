
$(document).ready(function(){
    $(".greeting").hide();
    $(".factorial").hide();
    $(".reverse").hide();
    $(".sum").hide();
    $("#mainDropDown option[value='0']").prop("disabled", true);

    $("#mainDropDown").change(function(){      
        if($(this).val() == "greeting"){
            $(".greeting").show();
            $(".factorial").hide();
            $(".reverse").hide();
            $(".sum").hide();

            $("#fname").attr("required", "");
            $("#lname").attr("required", "");
            $("#number").removeAttr("required");
            $("#string").removeAttr("required");
            $("#n1").removeAttr("required");
            $("#n2").removeAttr("required");

            $("#nameSubmit").prop("disabled", false);
            $("#numberSubmit").prop("disabled", true);
            $("#stringSubmit").prop("disabled", true);
            $("#nSubmit").prop("disabled", true);

            $("#nameClear").prop("disabled", false);
            $("#numberClear").prop("disabled", true);
            $("#stringClear").prop("disabled", true);
            $("#nClear").prop("disabled", true);

            $("#nameSubmit").click(function(){
                $("#fname").val(); 
                $("#lname").val(); 
                $("form").attr("method", "post");
            });

            $("#nameClear").click(function(){
                $("#fname").val(""); 
                $("#lname").val("");   
            });

        }
        if($(this).val() == "factorial"){
            $(".greeting").hide();
            $(".factorial").show();
            $(".reverse").hide();
            $(".sum").hide();

            $("#fname").removeAttr("required");
            $("#lname").removeAttr("required");
            $("#number").attr("required", "");
            $("#string").removeAttr("required");
            $("#n1").removeAttr("required");
            $("#n2").removeAttr("required");

            $("#nameSubmit").prop("disabled", true);
            $("#numberSubmit").prop("disabled", false);
            $("#stringSubmit").prop("disabled", true);
            $("#nSubmit").prop("disabled", true);

            $("#nameClear").prop("disabled", true);
            $("#numberClear").prop("disabled", false);
            $("#stringClear").prop("disabled", true);
            $("#nClear").prop("disabled", true);

            $("#numberSubmit").click(function(){
                $("#number").val();  
                $("form").attr("method", "get");
            });

            $("#numberClear").click(function(){
                $("#number").val("");  
            });
        }
        if($(this).val() == "reverse"){
            $(".greeting").hide();
            $(".factorial").hide();
            $(".reverse").show();
            $(".sum").hide();

            $("#fname").removeAttr("required");
            $("#lname").removeAttr("required");
            $("#number").removeAttr("required");
            $("#string").attr("required", "");
            $("#n1").removeAttr("required");
            $("#n2").removeAttr("required");

            $("#nameSubmit").prop("disabled", true);
            $("#numberSubmit").prop("disabled", true);
            $("#stringSubmit").prop("disabled", false);
            $("#nSubmit").prop("disabled", true);

            $("#nameClear").prop("disabled", true);
            $("#numberClear").prop("disabled", true);
            $("#stringClear").prop("disabled", false);
            $("#nClear").prop("disabled", true);

            $("#stringSubmit").click(function(){
                $("#string").val();                           $("form").attr("method", "get");
            });

             $("#stringClear").click(function(){
                $("#string").val("");  
            });
        }
        if($(this).val() == "sum"){
            $(".greeting").hide();
            $(".factorial").hide();
            $(".reverse").hide();
            $(".sum").show();

            $("#fname").removeAttr("required");
            $("#lname").removeAttr("required");
            $("#number").removeAttr("required");
            $("#string").removeAttr("required");
            $("#n1").attr("required", "");
            $("#n2").attr("required", "");

            $("#nameSubmit").prop("disabled", true);
            $("#numberSubmit").prop("disabled", true);
            $("#stringSubmit").prop("disabled", true);
            $("#nSubmit").prop("disabled", false);

            $("#nameClear").prop("disabled", true);
            $("#numberClear").prop("disabled", true);
            $("#stringClear").prop("disabled", true);
            $("#nClear").prop("disabled", false);

            $("#nSubmit").click(function(){
                $("#n1").val(); 
                $("#n2").val(); 
                $("form").attr("method", "get");
            });

             $("#nClear").click(function(){
                $("#n1").val("");   
                $("#n2").val(""); 
            });
        }
    });
});

