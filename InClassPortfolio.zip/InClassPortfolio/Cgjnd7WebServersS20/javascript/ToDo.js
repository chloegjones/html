var swap = false;
function clearForm() {
    var date = document.getElementById("date");
    var dropDown = document.getElementById("selector");
    var title = document.getElementById("title");

    date.value = null;
    dropDown.value = "";
    title.value = "";
    
    console.dir(date);
    console.dir(dropDown);
    console.dir(title);
    console.log(date);
    console.log(dropDown);
    console.log(title);
}
function switchTheme(){
    console.dir(document.body.style);
    if (swap) {
        document.body.style.background = null;
        document.body.style.background = 'url("/Cgjnd7WebServersS20/photos/backgroundimg.png") no-repeat center fixed cover';
        document.getElementById("mode").innerHTML= "Dark Mode";
        document.getElementById("formContainer").style.backgroundColor = "pink";
        document.getElementById("tableContainer").style.backgroundColor = "pink";
        console.log("inside if block");
        swap = false;
    }else{
        console.log("inside else block");
        document.getElementById("mode").innerHTML = "Light Mode";
        document.body.style.background = null;
        document.body.style.background = 'url("/Cgjnd7WebServersS20/photos/blackandwhite.jpg") no-repeat center fixed';
        document.getElementById("formContainer").style.backgroundColor = "black";
        document.getElementById("tableContainer").style.backgroundColor = "black";
        swap = true;
    }
}
function addItem() {
    if(validate()){
        var date = document.getElementById("date");
        var dropDown = document.getElementById("selector");
        var title = document.getElementById("title");
        var table = document.getElementById("table");
        var rowCount = table.rows.length;
        var btn = document.createElement("BUTTON");
        btn.innerHTML = "remove";

        var row = table.insertRow(rowCount);
        var cell1 = row.insertCell(0); cell2 = row.insertCell(1), cell3 = row.insertCell(2), cell4 = row.insertCell(3).appendChild(btn);

        cell1.innerHTML = title.value;
        cell2.innerHTML = dropDown.value;
        cell3.innerHTML = date.value;

        for(var i = 1; i < table.rows.length; i++){
            table.rows[i].cells[3].onclick = function(){
            var index = this.parentElement.rowIndex;
            table.deleteRow(index);
            console.log(index);
            }
        }
        clearForm();
    }
}
function validate() {
    var date = document.getElementById("date");
    var dropDown = document.getElementById("selector");
    var title = document.getElementById("title");
     if(title.value == "" || dropDown.value == "" ||  date.value == "") {
       alert("Please fill out all fields!");
         return false;
     }else{
        return(true);
     }
}