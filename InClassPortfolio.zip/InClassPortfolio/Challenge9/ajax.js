$(document).ready(function(){       
    //get content info
    $.get("https://www.mizzouit.com/2830/challenge9/classInfo.php?content=info", function(str){
        $("#contentInfo").html(str);
    });
    //content info loader
    document.getElementById("contentInfo").innerHTML = '<img alt = "loading" src="loading2.gif">';

    //get type
    $.get("https://www.mizzouit.com/2830/challenge9/classInfo.php?content=classType", function(str){
        $("#type").html(str); 
    });  
    //type loader
    document.getElementById("type").innerHTML = '<img alt = "loading" src="loading2.gif">';

    //xml Current Assignment + loader
    document.getElementById("assignment").innerHTML = '<img alt = "loading" src="loading2.gif">';
    var xmlHttp = new XMLHttpRequest();

    xmlHttp.onload = function(){
        if(xmlHttp.readyState ==4 && xmlHttp.status == 200){
            var xmlDoc = xmlHttp.responseXML;

            var currentAssignment = xmlDoc.getElementsByTagName("currentAssignment")[0].innerHTML;
            var date = new Date(xmlDoc.getElementsByTagName("dueDateTimestamp")[0].innerHTML * 1000);

            document.getElementById("assignment").innerHTML = currentAssignment + " is due on " + date;
        }
    }
    xmlHttp.open("GET", "https://www.mizzouit.com/2830/challenge9/classInfo.php?content=currentAssignment&format=xml", true);
    xmlHttp.send();
});

//json get office hour info + loader
function getContent(day){
    var xmlHttp = new XMLHttpRequest();

    xmlHttp.onreadystatechange = function(){
        if(xmlHttp.readyState == 4 && xmlHttp.status == 200){
            var xmlDoc = xmlHttp.responseText;
            var list = JSON.parse(xmlDoc).officeHours;
            var output = "";
            for(i=0; i < list.length; i++){
                output += "<br><li>" + list[i]['person'] + ' has office hours from ' + list[i]['time'] + " " + list[i]['location'] + "</li>";
            }
            
            document.getElementById("days").innerHTML = output;
        }
    }
    xmlHttp.open("GET", "https://www.mizzouit.com/2830/challenge9/classInfo.php?content=officeHours&format=json&day=" + day, true);
    xmlHttp.send();
    document.getElementById("days").innerHTML = '<img alt = "loading" src="loading2.gif">';
}
